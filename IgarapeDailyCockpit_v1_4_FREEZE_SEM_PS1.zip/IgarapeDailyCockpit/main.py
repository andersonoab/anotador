# -*- coding: utf-8 -*-
"""
main.py — Igarape Daily Cockpit (primeiro modelo completo, M1).

Interface 100% HTML/JS/CSS (pasta ui/). Python e a cola com o Windows.

Duas janelas:
  - CAPTURA: barrinha flutuante, chamada pelo atalho global (Ctrl+Alt+Espaco).
  - COCKPIT: janela principal (cockpit, triagem, aguardando, decisoes,
             exportacao Excel, configuracoes e plano de acao com IA).

O nucleo funciona SEM IA. A IA so entra no botao de plano de acao, com tela
de revisao editavel antes de qualquer envio (voce filtra dados sensiveis).
"""

import os
import sys
import json
import tempfile
import ctypes
import base64
import threading
from datetime import datetime

import webview

import db
import parsing
import export_excel
import ia
import audio
from hotkey import iniciar_hotkey
from tray import iniciar_tray


janela_captura = None
janela_cockpit = None
_gravador = audio.Gravador()


def _recarregar_cockpit(delay=0.10):
    """Atualiza a janela principal quando uma captura e criada/alterada.

    A captura e o Cockpit sao janelas separadas. Sem esta notificacao, uma
    nova nota de voz podia ficar gravada no SQLite, mas so aparecer depois de
    uma atualizacao manual da janela principal.
    """
    def _run():
        try:
            if delay:
                import time
                time.sleep(delay)
            if janela_cockpit:
                janela_cockpit.evaluate_js("window.recarregar && window.recarregar()")
        except Exception:
            # A janela pode ainda nao estar pronta/visivel. O dado ja esta no
            # SQLite e sera carregado normalmente na proxima abertura.
            pass
    threading.Thread(target=_run, daemon=True).start()


def _transcrever_salvar(ativ_id, caminho):
    """Executa a transcricao fora da UI e grava o resultado no SQLite."""
    try:
        resultado = audio.transcrever(caminho)
        if resultado.get("ok"):
            texto = (resultado.get("texto") or "").strip()
            db.atualizar(ativ_id, {
                "audio_transcricao": texto,
                "audio_motor": resultado.get("motor"),
                "audio_status": "concluida",
                "audio_erro": None,
                "texto_original": texto or "[nota de voz]",
            })
            print(f"[voz] transcricao concluida id={ativ_id} motor={resultado.get('motor')}")
        else:
            db.atualizar(ativ_id, {
                "audio_status": "erro",
                "audio_erro": resultado.get("erro") or "Falha na transcricao.",
            })
            print(f"[voz] transcricao falhou id={ativ_id}: {resultado.get('erro')}")
    except Exception as e:
        db.atualizar(ativ_id, {"audio_status": "erro", "audio_erro": str(e)})
        print(f"[voz] erro inesperado id={ativ_id}: {e}")
    finally:
        _recarregar_cockpit(0.05)


def _iniciar_transcricao(ativ_id, caminho):
    t = threading.Thread(target=_transcrever_salvar, args=(ativ_id, caminho), daemon=True)
    t.start()
    return True


# ===========================================================================
# API exposta ao JavaScript
# ===========================================================================
class Api:

    # ---- captura ----------------------------------------------------------
    def salvar_captura(self, texto):
        texto = (texto or "").strip()
        if not texto:
            return {"ok": False, "erro": "vazio"}
        prazo = parsing.sugerir_prazo(texto)
        resp = parsing.detectar_responsavel(texto, db.listar_responsaveis())
        codigo = db.criar_atividade(texto, "TEXTO", prazo, resp)
        print(f"[app] captura: {codigo} | prazo_sug={prazo}")
        _recarregar_cockpit()
        return {"ok": True, "codigo": codigo, "prazo_sugerido": prazo}

    def salvar_captura_organizada(self, texto, prioridade, destino, prazo_iso,
                                  aguardando_quem):
        """Shift+Enter: cria e ja tria em um passo so."""
        texto = (texto or "").strip()
        if not texto:
            return {"ok": False, "erro": "vazio"}
        codigo = db.criar_atividade(texto, "TEXTO")
        # localizar o id recem-criado
        alvo = None
        for a in db.caixa_entrada():
            if a["codigo"] == codigo:
                alvo = a["id"]
                break
        if alvo:
            db.triar(alvo, prioridade or "normal", destino or "minha",
                     prazo_iso, None, aguardando_quem, None)
        _recarregar_cockpit()
        return {"ok": True, "codigo": codigo}

    def esconder_captura(self):
        if janela_captura:
            janela_captura.hide()
        return True

    # ---- voz --------------------------------------------------------------
    def audio_disponivel(self):
        return {
            "disponivel": audio.DISPONIVEL,
            "transcricao": audio.status_transcricao(),
        }

    def iniciar_gravacao(self):
        return _gravador.iniciar()

    def cancelar_gravacao(self):
        return _gravador.cancelar()

    def parar_gravacao(self, titulo=None):
        """Salva a nota imediatamente e dispara a transcricao local em background."""
        r = _gravador.parar()
        if not r.get("ok"):
            return r

        titulo = (titulo or "").strip()
        if not titulo:
            titulo = datetime.now().strftime("Nota de voz %d/%m %H:%M")

        codigo = db.criar_atividade(
            "[nota de voz - transcricao em processamento]",
            "VOZ",
            None,
            None,
            r["arquivo"],
            titulo=titulo,
            audio_duracao=r.get("duracao"),
            audio_status="transcrevendo",
        )
        ativ_id = db.id_por_codigo(codigo)
        # Mostra a nota imediatamente na Caixa de entrada, antes mesmo do
        # Whisper terminar. Depois a propria transcricao atualiza o card.
        _recarregar_cockpit(0.02)
        if ativ_id:
            _iniciar_transcricao(ativ_id, r["arquivo"])

        return {
            "ok": True,
            "codigo": codigo,
            "titulo": titulo,
            "arquivo": r["arquivo"],
            "nome": r.get("nome"),
            "duracao": r.get("duracao"),
            "audio_status": "transcrevendo",
        }

    def obter_audio(self, ativ_id):
        """Entrega o WAV sob demanda para o player HTML, sem expor outro arquivo."""
        d = db.detalhe(ativ_id)
        if not d:
            return {"ok": False, "erro": "Nota nao encontrada."}
        caminho = d["atividade"].get("audio_arquivo")
        if not caminho or not os.path.isfile(caminho):
            return {"ok": False, "erro": "Arquivo de audio nao encontrado."}
        try:
            tamanho = os.path.getsize(caminho)
            if tamanho > 40 * 1024 * 1024:
                return {"ok": False, "erro": "Audio muito grande para o player interno."}
            with open(caminho, "rb") as f:
                dados = base64.b64encode(f.read()).decode("ascii")
            return {"ok": True, "mime": "audio/wav", "base64": dados}
        except Exception as e:
            return {"ok": False, "erro": str(e)}

    def retranscrever_audio(self, ativ_id):
        d = db.detalhe(ativ_id)
        if not d:
            return {"ok": False, "erro": "Nota nao encontrada."}
        caminho = d["atividade"].get("audio_arquivo")
        if not caminho or not os.path.isfile(caminho):
            return {"ok": False, "erro": "Arquivo de audio nao encontrado."}
        db.atualizar(ativ_id, {"audio_status": "transcrevendo", "audio_erro": None})
        _iniciar_transcricao(ativ_id, caminho)
        return {"ok": True, "status": "transcrevendo"}

    # ---- dados do cockpit -------------------------------------------------
    def carregar(self):
        st = ia.status()
        return {
            "contadores": db.contadores(),
            "atencao": db.atencao(),
            "entrada": db.caixa_entrada(),
            "aguardando": db.aguardando(),
            "decisoes": db.decisoes(),
            "ativas": db.ativas(),
            "responsaveis": db.listar_responsaveis(),
            "ia": st,
            "banco": db.resumo_banco(),
        }

    def adicionar(self, texto):
        return self.salvar_captura(texto)

    # ---- triagem e estados ------------------------------------------------
    def triar(self, ativ_id, prioridade, destino, prazo_iso, prazo_hora,
              aguardando_quem, followup_em):
        db.triar(ativ_id, prioridade, destino, prazo_iso, prazo_hora,
                 aguardando_quem, followup_em)
        return {"ok": True}

    def concluir(self, ativ_id):
        db.concluir(ativ_id); return {"ok": True}

    def cancelar(self, ativ_id, motivo):
        db.cancelar(ativ_id, motivo or ""); return {"ok": True}

    def adiar(self, ativ_id, ate_iso):
        db.adiar(ativ_id, ate_iso); return {"ok": True}

    def cobrar(self, ativ_id):
        novo = db.cobrar(ativ_id); return {"ok": True, "followup": novo}

    def detalhe(self, ativ_id):
        return db.detalhe(ativ_id)

    def atualizar(self, ativ_id, campos):
        db.atualizar(ativ_id, campos or {}); return {"ok": True}

    def sugerir(self, texto):
        return {"prazo_iso": parsing.sugerir_prazo_iso(texto or "")}

    def excluir_atividade(self, ativ_id):
        """Exclusao definitiva; para notas de voz remove tambem o WAV local."""
        try:
            return db.excluir_atividade(int(ativ_id), apagar_audio=True)
        except Exception as e:
            return {"ok": False, "erro": str(e)}

    def limpar_banco(self, confirmacao):
        """Zera o Cockpit somente quando a UI envia a palavra de confirmacao."""
        if (confirmacao or "").strip().upper() != "LIMPAR":
            return {"ok": False, "erro": "Confirmacao invalida. Digite LIMPAR."}
        try:
            _gravador.cancelar()
        except Exception:
            pass
        try:
            return db.limpar_banco(apagar_audios=True)
        except Exception as e:
            return {"ok": False, "erro": str(e)}

    # ---- exportacao Excel (local) -----------------------------------------
    def exportar(self, modelo, status_filtro, ini, fim):
        try:
            caminho = export_excel.gerar(modelo, status_filtro or "Todos",
                                         ini or None, fim or None)
            try:
                os.startfile(os.path.dirname(caminho))  # abre a pasta
            except Exception:
                pass
            return {"ok": True, "caminho": caminho}
        except Exception as e:
            return {"ok": False, "erro": str(e)}

    # ---- IA (plano de acao) -----------------------------------------------
    def ia_status(self):
        return ia.status()

    def ia_salvar_chave(self, chave):
        return ia.salvar_chave(chave)

    def ia_apagar_chave(self):
        return ia.apagar_chave()

    def ia_testar(self):
        return ia.testar_conexao()

    def ia_preparar_plano(self, ids):
        """
        Monta o texto que SERA enviado, para a tela de revisao.
        Marca possiveis dados sensiveis para o usuario editar antes de enviar.
        NADA e enviado aqui — so preparado localmente.
        """
        linhas = db.por_ids(ids or [])
        partes = []
        alertas = set()
        for a in linhas:
            if a.get("tipo_entrada") == "VOZ" and a.get("audio_transcricao"):
                nome = a.get("titulo") or "Nota de voz"
                txt = f"{nome}: {a.get('audio_transcricao')}"
            else:
                txt = a.get("titulo") or a.get("texto_original") or ""
            partes.append(f"- {txt}")
            for al in parsing.alertas_sensiveis(txt):
                alertas.add(al)
        return {
            "ok": True,
            "texto": "\n".join(partes),
            "alertas": sorted(alertas),
        }

    def ia_gerar_plano(self, texto_revisado, publico):
        return ia.gerar_plano(texto_revisado, publico or "equipe")


# ===========================================================================
# Janela / servicos
# ===========================================================================
def _base_aplicacao():
    """Pasta dos recursos do app, tanto no .py quanto no cx_Freeze."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def _ui(arquivo):
    return os.path.join(_base_aplicacao(), "ui", arquivo)


def _selftest_freeze():
    """Teste silencioso do executavel congelado, usado no build/CI.

    Nao abre janelas. Valida os dois HTMLs e a pilha principal de imports do
    executavel, incluindo a transcricao local. So e executado quando
    IGARAPE_FREEZE_SELFTEST=1 estiver definido.
    """
    if os.getenv("IGARAPE_FREEZE_SELFTEST") != "1":
        return False

    resultado = {
        "frozen": bool(getattr(sys, "frozen", False)),
        "executable": sys.executable,
        "base": _base_aplicacao(),
        "cockpit_html": os.path.isfile(_ui("cockpit.html")),
        "captura_html": os.path.isfile(_ui("captura.html")),
        "imports": {},
    }

    modulos = [
        "webview", "cffi", "pycparser", "clr_loader", "pythonnet",
        "pystray", "PIL", "openpyxl", "keyring", "sounddevice",
        "soundfile", "numpy", "faster_whisper", "av", "ctranslate2",
        "tokenizers", "onnxruntime", "huggingface_hub",
    ]
    for nome in modulos:
        try:
            __import__(nome)
            resultado["imports"][nome] = "ok"
        except Exception as exc:
            resultado["imports"][nome] = f"ERRO: {type(exc).__name__}: {exc}"

    resultado["ok"] = (
        resultado["frozen"]
        and resultado["cockpit_html"]
        and resultado["captura_html"]
        and all(v == "ok" for v in resultado["imports"].values())
    )

    saida = os.getenv(
        "IGARAPE_SELFTEST_OUTPUT",
        os.path.join(tempfile.gettempdir(), "igarape_freeze_selftest.json"),
    )
    try:
        with open(saida, "w", encoding="utf-8") as f:
            json.dump(resultado, f, ensure_ascii=False, indent=2)
    except Exception:
        pass
    return True


def _centro_horizontal(largura):
    try:
        return int((ctypes.windll.user32.GetSystemMetrics(0) - largura) / 2)
    except Exception:
        return 400


def mostrar_captura():
    if janela_captura:
        try:
            janela_captura.show()
            janela_captura.evaluate_js("window.focarInput && window.focarInput()")
        except Exception as e:
            print("[app] erro captura:", e)


def mostrar_cockpit():
    if janela_cockpit:
        try:
            janela_cockpit.show()
            janela_cockpit.evaluate_js("window.recarregar && window.recarregar()")
        except Exception as e:
            print("[app] erro cockpit:", e)


def encerrar():
    for j in (janela_captura, janela_cockpit):
        try:
            if j:
                j.destroy()
        except Exception:
            pass
    os._exit(0)


def iniciar_servicos():
    iniciar_hotkey(callback=mostrar_captura)
    iniciar_tray(on_captura=mostrar_captura,
                 on_cockpit=mostrar_cockpit,
                 on_sair=encerrar)
    print("[app] Pronto. Ctrl+Alt+Espaco captura. Cockpit pela bandeja.")


def main():
    if _selftest_freeze():
        return

    db.inicializar()
    print("[app] Banco em:", db.DB_PATH)
    print("[app] IA:", ia.status())

    cockpit_html = _ui("cockpit.html")
    captura_html = _ui("captura.html")
    print("[app] UI cockpit:", cockpit_html)
    print("[app] UI captura:", captura_html)
    if not os.path.isfile(cockpit_html):
        raise FileNotFoundError(f"UI nao encontrada: {cockpit_html}")
    if not os.path.isfile(captura_html):
        raise FileNotFoundError(f"UI nao encontrada: {captura_html}")

    global janela_captura, janela_cockpit
    api = Api()

    # janela principal (cockpit) — comeca visivel
    janela_cockpit = webview.create_window(
        "Igarape Daily Cockpit",
        url=cockpit_html,
        js_api=api,
        width=1120, height=760,
        min_size=(900, 600),
        background_color="#FFFFFF",
    )

    # barrinha de captura — escondida, aparece no atalho
    lg = 560
    janela_captura = webview.create_window(
        "Captura rapida",
        url=captura_html,
        js_api=api,
        width=lg, height=190,
        x=_centro_horizontal(lg), y=170,
        frameless=True, on_top=True, resizable=False,
        easy_drag=True, hidden=True,
        background_color="#FFFFFF",
    )

    webview.start(iniciar_servicos)


if __name__ == "__main__":
    main()
