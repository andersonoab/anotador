@echo off
setlocal EnableExtensions
set "ROOT=%~dp0"
cd /d "%ROOT%"

if not exist "%ROOT%main.py" (
  echo ERRO: main.py nao foi encontrado ao lado de iniciar.bat.
  echo Nao execute o BAT diretamente dentro do ZIP. Use "Extrair tudo" primeiro.
  echo.
  pause
  exit /b 3
)

if not exist "%ROOT%.venv\Scripts\python.exe" (
  echo Ambiente .venv ainda nao preparado.
  echo Execute instalar_voz.bat uma vez e depois volte ao iniciar.bat.
  echo.
  pause
  exit /b 2
)

"%ROOT%.venv\Scripts\python.exe" "%ROOT%main.py"
pause
