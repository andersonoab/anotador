@echo off
setlocal
chcp 65001 >nul

echo ============================================================
echo   Igarape Daily Cockpit - LIMPAR BANCO MANUALMENTE
echo ============================================================
echo.
echo Feche o Igarape Daily Cockpit antes de continuar.
echo Este procedimento apaga apenas o arquivo do banco:
echo C:\_RPA\DailyCockpit\data\cockpit.db
echo.
echo Os arquivos WAV da pasta de audios NAO sao apagados por este BAT.
echo Para apagar banco + audios, use Configuracoes ^> Limpar banco no Cockpit.
echo.
set /p CONF=Digite LIMPAR para continuar: 
if /I not "%CONF%"=="LIMPAR" (
  echo.
  echo Operacao cancelada.
  pause
  exit /b 1
)

del /q "C:\_RPA\DailyCockpit\data\cockpit.db" 2>nul
if exist "C:\_RPA\DailyCockpit\data\cockpit.db" (
  echo.
  echo Nao foi possivel apagar o banco. Confirme se o Cockpit esta fechado.
) else (
  echo.
  echo Banco apagado. Na proxima abertura o Cockpit criara um banco novo vazio.
)
echo.
pause
