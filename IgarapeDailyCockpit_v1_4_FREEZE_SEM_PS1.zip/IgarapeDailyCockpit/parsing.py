# -*- coding: utf-8 -*-
"""
parsing.py — Leitura leve do texto capturado (offline, SEM IA).

Sugere prazo e detecta um possivel responsavel (entre os ja cadastrados).
Tudo aqui e regra simples de texto: instantaneo, sem rede, sem chave.
"""

import re
from datetime import datetime, timedelta


_DIAS_SEMANA = {
    "segunda": 0, "terca": 1, "terça": 1, "quarta": 2, "quinta": 3,
    "sexta": 4, "sabado": 5, "sábado": 5, "domingo": 6,
}


def sugerir_prazo(texto):
    """Retorna data dd/mm/aaaa se achar pista de tempo; senao None."""
    if not texto:
        return None
    t = texto.lower()
    hoje = datetime.now()

    def fmt(dt):
        return dt.strftime("%d/%m/%Y")

    if "depois de amanha" in t or "depois de amanhã" in t:
        return fmt(hoje + timedelta(days=2))
    if "amanha" in t or "amanhã" in t:
        return fmt(hoje + timedelta(days=1))
    if "hoje" in t:
        return fmt(hoje)
    if "proxima semana" in t or "próxima semana" in t or "semana que vem" in t:
        return fmt(hoje + timedelta(days=7))

    for nome, idx in _DIAS_SEMANA.items():
        if re.search(r"\b" + re.escape(nome) + r"\b", t):
            delta = (idx - hoje.weekday()) % 7
            delta = 7 if delta == 0 else delta
            return fmt(hoje + timedelta(days=delta))
    return None


def sugerir_prazo_iso(texto):
    """Mesma sugestao, mas em ISO (yyyy-mm-dd) para gravar no banco."""
    br = sugerir_prazo(texto)
    if not br:
        return None
    try:
        return datetime.strptime(br, "%d/%m/%Y").strftime("%Y-%m-%d")
    except Exception:
        return None


def detectar_responsavel(texto, nomes_conhecidos):
    """
    Se o texto mencionar um nome ja cadastrado, retorna esse nome.
    Ajuda a pre-preencher 'aguardando de quem'.
    """
    if not texto or not nomes_conhecidos:
        return None
    t = texto.lower()
    for nome in nomes_conhecidos:
        if nome and re.search(r"\b" + re.escape(nome.lower()) + r"\b", t):
            return nome
    return None


# Pistas simples de que algo pode ser sensivel (usado so como AVISO local,
# nunca bloqueia; ajuda o usuario a lembrar de editar antes de enviar a IA).
_PISTAS_SENSIVEIS = [
    (r"r\$\s*\d", "valor em R$"),
    (r"\b\d{3}\.?\d{3}\.?\d{3}-?\d{2}\b", "possivel CPF"),
    (r"\bsalari", "salario"),
    (r"\brescis", "rescisao"),
    (r"\bfolha\b", "folha"),
    (r"\bvalor\b", "valor"),
]


def alertas_sensiveis(texto):
    """Retorna lista de rotulos de possiveis dados sensiveis no texto."""
    if not texto:
        return []
    t = texto.lower()
    achados = []
    for padrao, rotulo in _PISTAS_SENSIVEIS:
        if re.search(padrao, t):
            achados.append(rotulo)
    return sorted(set(achados))


if __name__ == "__main__":
    exemplos = [
        "cobrar Jair amanha sobre homologacao da rescisao",
        "conferir fechamento da folha hoje 17h",
        "retorno PGR bloco E sexta",
        "pagar R$ 4.200 de PLR proxima semana",
    ]
    for e in exemplos:
        print(f"{e!r:55} prazo={sugerir_prazo(e)} sensivel={alertas_sensiveis(e)}")
