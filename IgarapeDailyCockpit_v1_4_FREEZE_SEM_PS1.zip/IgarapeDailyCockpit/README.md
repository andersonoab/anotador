# Igarapé Daily Cockpit — Primeiro Modelo Completo (M1)

Sistema operacional pessoal da rotina de DP/RH. Captura pensamentos em 2 segundos, organiza o que virou trabalho, mostra o cockpit de decisão e exporta para Excel. Interface 100% em HTML/JS/CSS (renderizada via pywebview); o Python é apenas a cola com o Windows. **O núcleo funciona sem IA** — a inteligência artificial entra somente para gerar plano de ação, quando você clicar, e sempre com uma tela de revisão editável antes de qualquer envio, para você filtrar dados sensíveis.

## O que já está incluído neste modelo

Captura rápida por atalho global (`Ctrl+Alt+Espaço`) de qualquer lugar: `Enter` salva em 2 segundos; `Shift+Enter` abre o painel para organizar na hora (prioridade, destino, prazo). Captura por voz com nome da nota, gravação local em `.wav`, transcrição automática em português e player dentro da própria caixa de entrada/detalhe. A transcrição roda em segundo plano e pode ser corrigida manualmente. Cockpit principal com contadores de Críticos, Para hoje, Atrasados, Decisões e Aguardando, mais a lista do que precisa de atenção. Caixa de entrada com triagem em lote (prioridade, destino minha/aguardando/decisão, prazo com atalhos e calendário, "salvar e próxima"). Radar de cobrança para o que está aguardando terceiros, com contagem de dias e follow-up automático ("cobrei" empurra +3 dias). Decisões separadas do operacional. Detalhe de qualquer atividade por duplo clique, com edição completa e histórico. Exportação para Excel em três modelos (Plano de Ação DP operacional, Plano Executivo para diretoria, Base completa), com célula Calibri Light 8pt. Configuração da IA com chave protegida no keyring do Windows. Geração de plano de ação com IA, sob controle total: você seleciona as atividades, revisa e edita o texto (com alerta de possíveis dados sensíveis), e só então envia.

## Fundação já validada na máquina real

O protótipo anterior confirmou, na sua máquina da Sonova, que o atalho global funciona sob a GPO, que a barrinha aparece sobre outros aplicativos e que o SQLite grava corretamente em `C:\_RPA\DailyCockpit\data\cockpit.db`. Este modelo é construído sobre essa fundação testada.

## Instalação

Requer Windows e Python 3.10+. Instale as dependências do projeto:

```
python -m pip install -r requirements.txt
```

Para uma máquina que já tinha a versão anterior, basta dar duplo clique em `instalar_voz.bat`. Ele instala gravação + `faster-whisper` e tenta baixar antecipadamente o modelo `base`. O download do modelo ocorre uma única vez; depois a transcrição funciona localmente. Se o Whisper não puder ser usado, o app tenta o reconhecedor de fala do Windows em português. Use sempre `python -m pip` (não apenas `pip`) para garantir que a instalação vá para o mesmo Python que executa o app.

## Como rodar

```
python main.py
```

Ou dê duplo clique em `iniciar.bat`. A janela do cockpit abre; a barrinha de captura fica escondida e aparece com `Ctrl+Alt+Espaço` ou pelo ícone na bandeja (perto do relógio), que também abre o cockpit e encerra o app.

## Onde ficam os dados

O banco fica em `C:\_RPA\DailyCockpit\data\cockpit.db` (padrão), com fallback automático para uma pasta `data\` ao lado do `main.py` se a primeira não for gravável. Os Excels vão para `C:\_RPA\DailyCockpit\exports\` (a pasta abre sozinha após gerar). Para conferir as atividades por linha de comando: `python db.py`.

## A regra de dados sensíveis (LGPD)

O núcleo é local. As gravações e a transcrição permanecem na máquina; o Whisper processa o áudio localmente após o modelo estar instalado. A única coisa que sai da máquina é o texto que você **decidir** enviar à IA para o plano de ação — e mesmo esse passa antes por uma tela de revisão editável, onde você apaga nomes, valores e qualquer dado sensível. O sistema ainda destaca automaticamente possíveis dados sensíveis (valores em R$, CPF, "rescisão", "folha") como lembrete para você editar. Anexos e áudio nunca são enviados. Você é o filtro, sempre.

## Estrutura

| Arquivo | Papel |
|---|---|
| `main.py` | Orquestra as duas janelas (captura + cockpit), atalho, bandeja e a API JS↔Python |
| `ui/cockpit.html` | Janela principal: cockpit, triagem, aguardando, decisões, exportar, config, plano IA |
| `ui/captura.html` | Barrinha flutuante de captura (rápida + organizada + voz) |
| `db.py` | SQLite: schema completo, triagem, estados, consultas do cockpit |
| `parsing.py` | Sugestão de prazo e detecção de pessoa/dados sensíveis (offline, sem IA) |
| `export_excel.py` | Geração dos três modelos de Excel (openpyxl) |
| `ia.py` | Camada de IA opcional: plano de ação via API Anthropic, chave no keyring |
| `audio.py` | Gravação WAV, transcrição local (Whisper/Windows) e tratamento de falhas |
| `hotkey.py` | Atalho global via RegisterHotKey (sem hook) |
| `tray.py` | Ícone da bandeja |
| `iniciar.bat` | Inicialização via python.exe |
| `instalar_voz.bat` | Instala os componentes de gravação/transcrição e pré-carrega o Whisper |

## Decisões adotadas neste modelo (e como mudar)

Na triagem, ao marcar "Aguardando alguém", aparece um campo opcional para dizer de quem você está esperando — se preenchido, liga o radar de cobrança com follow-up padrão de 3 dias. Deixar em branco também funciona. A prioridade padrão na triagem é Normal. O modelo de IA padrão é Haiku (`claude-haiku-4-5-20251001`), configurável na tela de Configurações; se esse identificador mudar no futuro, basta atualizar o campo Modelo. O follow-up padrão de 3 dias e o atalho `Ctrl+Alt+Espaço` podem ser ajustados no código (`db.py` e `hotkey.py`, respectivamente).

## Voz — fluxo implementado

Clique no microfone na captura rápida, fale e use o campo principal para dar um nome à nota (ex.: `Reunião PLR`). `Enter` ou o botão quadrado encerra a gravação. A nota entra imediatamente na Caixa de entrada com o nome escolhido; a transcrição roda em segundo plano. Enquanto isso, o card mostra `transcrevendo...`. Quando terminar, o texto aparece no próprio card. O botão `Ouvir` carrega o áudio somente quando necessário e abre o player interno. No detalhe da atividade, a transcrição é editável. Em caso de falha existe `Transcrever novamente`.

A primeira execução do `faster-whisper` pode precisar baixar o modelo `base` (aprox. centenas de MB, conforme a versão). Depois disso o reconhecimento é local. Se o proxy bloquear esse download, o sistema tenta o reconhecimento de fala instalado no Windows. Nenhum áudio é enviado para a API de plano de ação.

## O que ainda depende de validação

A geração de plano com IA precisa que o proxy corporativo libere o acesso a `api.anthropic.com`. Se estiver bloqueado, o botão de plano avisa com clareza e o restante do app continua funcionando normalmente. Use "Testar conexão" nas Configurações para validar. A notificação toast do Windows (popup persistente) continua como próxima etapa.

## Próximos passos sugeridos

Popup de lembrete persistente, lembretes recorrentes por atividade, busca por texto dentro das transcrições e a ponte com o Leitor Outlook RH para transformar e-mails em atividades.

---

Anderson Marinho | Igarapé Digital

## Correcao v1.2 — erro de reconhecedor portugues do Windows

Se aparecer `Nenhum reconhecedor de fala em portugues esta instalado no Windows`, o problema e apenas do motor de contingencia do Windows. A v1.2 passa a usar um ambiente `.venv` proprio para garantir que `faster-whisper` seja instalado no mesmo Python que executa o Cockpit. Feche o app, execute `instalar_voz.bat` uma vez e, depois, abra sempre por `iniciar.bat`. Para conferir o ambiente, use `diagnostico_voz.bat`. A atualizacao nao apaga o banco nem os audios existentes em `C:\_RPA\DailyCockpit`.


## Novidade v1.3 — exclusao e limpeza do banco

Agora e possivel excluir definitivamente uma nota/atividade pelo detalhe. Nas notas de voz, o botao `Excluir nota` tambem remove o arquivo WAV associado. A tela `Configuracoes` ganhou a area `Manutencao do banco`, que mostra o caminho do SQLite e permite zerar todas as atividades, historicos e audios mediante dupla confirmacao e digitacao da palavra `LIMPAR`.

Para emergencia/manutencao externa, existe tambem `limpar_banco.bat`, equivalente ao comando `del "C:\_RPA\DailyCockpit\data\cockpit.db"`. Esse BAT deve ser executado com o Cockpit fechado e apaga somente o banco; os WAVs permanecem. Para limpeza completa, prefira o botao dentro do Cockpit.

## Correcao v1.4 — notas visiveis e instalacao fora do ZIP

- Ao salvar uma nota de voz, o Cockpit principal e recarregado automaticamente. A nota aparece imediatamente na Caixa de entrada com status `transcrevendo...`; quando o Whisper termina, o mesmo card e atualizado.
- Capturas de texto e capturas organizadas tambem atualizam a janela principal automaticamente.
- `instalar_voz.bat`, `iniciar.bat` e `diagnostico_voz.bat` agora detectam quando foram abertos diretamente dentro do ZIP e mostram a orientacao correta, em vez de falhar com `requirements.txt` ausente.
- O instalador usa caminhos absolutos para `requirements.txt` e para o `.venv`, evitando depender da pasta corrente do Prompt.
