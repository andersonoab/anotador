# -*- coding: utf-8 -*-
"""
db.py — Camada de banco (SQLite) do Igarape Daily Cockpit.

Principio central: SQLite e a FONTE OFICIAL. Excel e SAIDA.
Este modulo nao usa internet nem IA. Tudo aqui e local e instantaneo.
"""

import os
import sys
import sqlite3
from datetime import datetime, date, timedelta


# ---------------------------------------------------------------------------
# Localizacao do banco
# ---------------------------------------------------------------------------
def _pasta_dados():
    if os.name == "nt":
        preferido = r"C:\_RPA\DailyCockpit\data"
        try:
            os.makedirs(preferido, exist_ok=True)
            teste = os.path.join(preferido, ".escrita_ok")
            with open(teste, "w", encoding="utf-8") as f:
                f.write("ok")
            os.remove(teste)
            return preferido
        except Exception:
            pass
    if getattr(sys, "frozen", False):
        base = os.path.dirname(os.path.abspath(sys.executable))
    else:
        base = os.path.dirname(os.path.abspath(__file__))
    local = os.path.join(base, "data")
    os.makedirs(local, exist_ok=True)
    return local


PASTA_DADOS = _pasta_dados()
DB_PATH = os.path.join(PASTA_DADOS, "cockpit.db")


def conectar():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def _agora():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _hoje_iso():
    return date.today().strftime("%Y-%m-%d")


# ---------------------------------------------------------------------------
# Migracao — completa colunas que faltam em bancos antigos (sem apagar dados)
# ---------------------------------------------------------------------------
# Colunas esperadas na tabela 'atividades' e o SQL de cada uma.
_COLUNAS_ATIVIDADES = {
    "titulo": "TEXT",
    "tipo_entrada": "TEXT DEFAULT 'TEXTO'",
    "status": "TEXT DEFAULT 'entrada'",
    "prioridade": "TEXT",
    "prazo": "TEXT",
    "prazo_hora": "TEXT",
    "prazo_sugerido": "TEXT",
    "responsavel_sugerido": "TEXT",
    "precisa_decisao": "INTEGER DEFAULT 0",
    "delegavel": "INTEGER DEFAULT 0",
    "aguardando_quem": "TEXT",
    "aguardando_desde": "TEXT",
    "followup_em": "TEXT",
    "categoria": "TEXT",
    "programa": "TEXT",
    "owner": "TEXT",
    "origem": "TEXT",
    "impacto": "TEXT",
    "risco": "TEXT",
    "decisao_necessaria": "TEXT",
    "valor": "TEXT",
    "progresso": "INTEGER DEFAULT 0",
    "notes": "TEXT",
    "audio_arquivo": "TEXT",
    "audio_transcricao": "TEXT",
    "audio_duracao": "REAL",
    "audio_motor": "TEXT",
    "audio_status": "TEXT",
    "audio_erro": "TEXT",
    "ia_utilizada": "INTEGER DEFAULT 0",
    "motivo_cancelamento": "TEXT",
    "atualizado_em": "TEXT",
}


def _migrar_colunas(cur):
    cur.execute("PRAGMA table_info(atividades)")
    existentes = {r[1] for r in cur.fetchall()}
    for nome, tipo in _COLUNAS_ATIVIDADES.items():
        if nome not in existentes:
            try:
                cur.execute(f"ALTER TABLE atividades ADD COLUMN {nome} {tipo}")
                print(f"[db] coluna adicionada: {nome}")
            except Exception as e:
                print(f"[db] falha ao adicionar {nome}: {e}")
    # Preenche 'titulo' vazio a partir do texto original, para linhas antigas.
    try:
        cur.execute(
            "UPDATE atividades SET titulo = substr(texto_original,1,80) "
            "WHERE titulo IS NULL OR titulo = ''"
        )
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Criacao das tabelas
# ---------------------------------------------------------------------------
def inicializar():
    con = conectar()
    cur = con.cursor()

    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS atividades (
            id                   INTEGER PRIMARY KEY AUTOINCREMENT,
            codigo               TEXT UNIQUE,
            texto_original       TEXT NOT NULL,
            titulo               TEXT,
            tipo_entrada         TEXT DEFAULT 'TEXTO',
            status               TEXT DEFAULT 'entrada',
            prioridade           TEXT,
            prazo                TEXT,
            prazo_hora           TEXT,
            prazo_sugerido       TEXT,
            responsavel_sugerido TEXT,
            precisa_decisao      INTEGER DEFAULT 0,
            delegavel            INTEGER DEFAULT 0,
            aguardando_quem      TEXT,
            aguardando_desde     TEXT,
            followup_em          TEXT,
            categoria            TEXT,
            programa             TEXT,
            owner                TEXT,
            origem               TEXT,
            impacto              TEXT,
            risco                TEXT,
            decisao_necessaria   TEXT,
            valor                TEXT,
            progresso            INTEGER DEFAULT 0,
            notes                TEXT,
            audio_arquivo        TEXT,
            audio_transcricao    TEXT,
            audio_duracao        REAL,
            audio_motor          TEXT,
            audio_status         TEXT,
            audio_erro           TEXT,
            ia_utilizada         INTEGER DEFAULT 0,
            motivo_cancelamento  TEXT,
            criado_em            TEXT NOT NULL,
            atualizado_em        TEXT NOT NULL
        )
        """
    )

    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS historico (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            atividade_id INTEGER NOT NULL,
            evento       TEXT NOT NULL,
            detalhe      TEXT,
            em           TEXT NOT NULL
        )
        """
    )

    # --- Migracao automatica ---
    # Se o banco veio de uma versao anterior (protótipo), a tabela existe mas
    # pode faltar colunas novas. CREATE TABLE IF NOT EXISTS nao altera tabela
    # existente, entao completamos aqui, sem apagar nada.
    _migrar_colunas(cur)

    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS responsaveis (
            id    INTEGER PRIMARY KEY AUTOINCREMENT,
            nome  TEXT UNIQUE NOT NULL
        )
        """
    )

    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS configuracoes (
            chave TEXT PRIMARY KEY,
            valor TEXT
        )
        """
    )

    con.commit()
    con.close()


# ---------------------------------------------------------------------------
# Helpers internos
# ---------------------------------------------------------------------------
def _log(cur, atividade_id, evento, detalhe=""):
    cur.execute(
        "INSERT INTO historico (atividade_id, evento, detalhe, em) VALUES (?,?,?,?)",
        (atividade_id, evento, detalhe, _agora()),
    )


def _gerar_codigo(cur):
    hoje = datetime.now().strftime("%Y%m%d")
    cur.execute(
        "SELECT COUNT(*) FROM atividades WHERE substr(codigo, 5, 8) = ?", (hoje,)
    )
    n = cur.fetchone()[0] + 1
    return f"ACT-{hoje}-{n:03d}"


def _dias_desde(iso_data):
    if not iso_data:
        return None
    try:
        d = datetime.strptime(iso_data[:10], "%Y-%m-%d").date()
        return (date.today() - d).days
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Criacao / captura
# ---------------------------------------------------------------------------
def criar_atividade(texto, tipo_entrada="TEXTO", prazo_sugerido=None,
                    responsavel_sugerido=None, audio_arquivo=None, titulo=None,
                    audio_transcricao=None, audio_duracao=None,
                    audio_motor=None, audio_status=None, audio_erro=None):
    con = conectar()
    cur = con.cursor()
    agora = _agora()
    codigo = _gerar_codigo(cur)
    titulo_final = (titulo or texto or "Atividade").strip()[:120]
    cur.execute(
        """
        INSERT INTO atividades
            (codigo, texto_original, titulo, tipo_entrada, status,
             prazo_sugerido, responsavel_sugerido, audio_arquivo,
             audio_transcricao, audio_duracao, audio_motor, audio_status,
             audio_erro, criado_em, atualizado_em)
        VALUES (?,?,?,?,'entrada',?,?,?,?,?,?,?,?,?,?)
        """,
        (codigo, texto, titulo_final, tipo_entrada, prazo_sugerido,
         responsavel_sugerido, audio_arquivo, audio_transcricao,
         audio_duracao, audio_motor, audio_status, audio_erro, agora, agora),
    )
    ativ_id = cur.lastrowid
    _log(cur, ativ_id, "CRIADA", f"tipo={tipo_entrada}; status=entrada")
    con.commit()
    con.close()
    return codigo


def id_por_codigo(codigo):
    con = conectar(); cur = con.cursor()
    cur.execute("SELECT id FROM atividades WHERE codigo=?", (codigo,))
    r = cur.fetchone()
    con.close()
    return r["id"] if r else None


# ---------------------------------------------------------------------------
# Triagem  (o coracao da organizacao)
# ---------------------------------------------------------------------------
def triar(ativ_id, prioridade=None, destino="minha", prazo=None, prazo_hora=None,
          aguardando_quem=None, followup_em=None):
    """
    destino:
      'minha'      -> status 'ativa'
      'aguardando' -> status 'aguardando_terceiro' (+ quem/desde/followup)
      'decisao'    -> status 'aguardando_decisao' (+ precisa_decisao=1)
    """
    con = conectar()
    cur = con.cursor()
    agora = _agora()

    if destino == "aguardando":
        status = "aguardando_terceiro"
        desde = _hoje_iso()
        if not followup_em:
            followup_em = (date.today() + timedelta(days=3)).strftime("%Y-%m-%d")
        cur.execute(
            """
            UPDATE atividades SET status=?, prioridade=?, prazo=?, prazo_hora=?,
                   aguardando_quem=?, aguardando_desde=?, followup_em=?,
                   atualizado_em=? WHERE id=?
            """,
            (status, prioridade, prazo, prazo_hora, aguardando_quem, desde,
             followup_em, agora, ativ_id),
        )
        if aguardando_quem:
            _registrar_responsavel(cur, aguardando_quem)
        _log(cur, ativ_id,
             "STATUS",
             f"aguardando_terceiro; quem={aguardando_quem}; followup={followup_em}")

    elif destino == "decisao":
        status = "aguardando_decisao"
        cur.execute(
            """
            UPDATE atividades SET status=?, prioridade=?, prazo=?, prazo_hora=?,
                   precisa_decisao=1, atualizado_em=? WHERE id=?
            """,
            (status, prioridade, prazo, prazo_hora, agora, ativ_id),
        )
        _log(cur, ativ_id, "STATUS", "aguardando_decisao")

    else:  # minha
        status = "ativa"
        cur.execute(
            """
            UPDATE atividades SET status=?, prioridade=?, prazo=?, prazo_hora=?,
                   atualizado_em=? WHERE id=?
            """,
            (status, prioridade, prazo, prazo_hora, agora, ativ_id),
        )
        _log(cur, ativ_id, "STATUS", f"ativa; prioridade={prioridade}")

    con.commit()
    con.close()
    return True


# ---------------------------------------------------------------------------
# Mudancas de estado
# ---------------------------------------------------------------------------
def concluir(ativ_id):
    con = conectar(); cur = con.cursor()
    cur.execute("UPDATE atividades SET status='concluida', progresso=100, atualizado_em=? WHERE id=?",
                (_agora(), ativ_id))
    _log(cur, ativ_id, "STATUS", "concluida")
    con.commit(); con.close()
    return True


def cancelar(ativ_id, motivo=""):
    con = conectar(); cur = con.cursor()
    cur.execute("UPDATE atividades SET status='cancelada', motivo_cancelamento=?, atualizado_em=? WHERE id=?",
                (motivo, _agora(), ativ_id))
    _log(cur, ativ_id, "STATUS", f"cancelada; motivo={motivo}")
    con.commit(); con.close()
    return True


def adiar(ativ_id, ate_iso):
    con = conectar(); cur = con.cursor()
    cur.execute("UPDATE atividades SET status='adiada', prazo=?, atualizado_em=? WHERE id=?",
                (ate_iso, _agora(), ativ_id))
    _log(cur, ativ_id, "STATUS", f"adiada ate {ate_iso}")
    con.commit(); con.close()
    return True


def cobrar(ativ_id):
    """Registra que voce cobrou e empurra o follow-up +3 dias."""
    con = conectar(); cur = con.cursor()
    novo = (date.today() + timedelta(days=3)).strftime("%Y-%m-%d")
    cur.execute("UPDATE atividades SET followup_em=?, atualizado_em=? WHERE id=?",
                (novo, _agora(), ativ_id))
    _log(cur, ativ_id, "COBRANCA", f"cobrado; novo followup={novo}")
    con.commit(); con.close()
    return novo


def atualizar(ativ_id, campos):
    """Atualiza campos livres a partir de um dicionario (tela de detalhe)."""
    permitidos = {
        "texto_original", "titulo", "prioridade", "status", "prazo", "prazo_hora",
        "aguardando_quem", "followup_em", "categoria", "programa", "owner",
        "origem", "impacto", "risco", "decisao_necessaria", "valor",
        "progresso", "notes", "precisa_decisao", "delegavel",
        "audio_transcricao", "audio_duracao", "audio_motor",
        "audio_status", "audio_erro",
    }
    sets, vals = [], []
    for k, v in (campos or {}).items():
        if k in permitidos:
            sets.append(f"{k}=?")
            vals.append(v)
    if not sets:
        return False
    sets.append("atualizado_em=?")
    vals.append(_agora())
    vals.append(ativ_id)
    con = conectar(); cur = con.cursor()
    cur.execute(f"UPDATE atividades SET {', '.join(sets)} WHERE id=?", vals)
    alteradas = cur.rowcount
    if alteradas:
        _log(cur, ativ_id, "EDITADA", "; ".join(f"{k}" for k in campos.keys()))
    con.commit(); con.close()
    return bool(alteradas)



# ---------------------------------------------------------------------------
# Exclusao / manutencao
# ---------------------------------------------------------------------------
def _remover_audio_seguro(caminho):
    """Remove apenas arquivos dentro da pasta de audios do Cockpit."""
    if not caminho:
        return False
    try:
        alvo = os.path.abspath(caminho)
        pasta_audio = os.path.abspath(os.path.join(PASTA_DADOS, "..", "audios"))
        if not (alvo == pasta_audio or alvo.startswith(pasta_audio + os.sep)):
            print(f"[db] audio fora da pasta permitida, nao removido: {alvo}")
            return False
        if os.path.isfile(alvo):
            os.remove(alvo)
            return True
    except Exception as e:
        print(f"[db] falha ao remover audio: {e}")
    return False


def excluir_atividade(ativ_id, apagar_audio=True):
    """Exclui definitivamente uma atividade, historico e audio associado."""
    con = conectar(); cur = con.cursor()
    cur.execute("SELECT id, codigo, titulo, tipo_entrada, audio_arquivo FROM atividades WHERE id=?", (ativ_id,))
    r = cur.fetchone()
    if not r:
        con.close()
        return {"ok": False, "erro": "Nota/atividade nao encontrada."}

    dados = dict(r)
    cur.execute("DELETE FROM historico WHERE atividade_id=?", (ativ_id,))
    cur.execute("DELETE FROM atividades WHERE id=?", (ativ_id,))
    con.commit(); con.close()

    audio_apagado = False
    if apagar_audio and dados.get("audio_arquivo"):
        audio_apagado = _remover_audio_seguro(dados.get("audio_arquivo"))

    return {
        "ok": True,
        "id": ativ_id,
        "codigo": dados.get("codigo"),
        "tipo": dados.get("tipo_entrada"),
        "audio_apagado": audio_apagado,
    }


def resumo_banco():
    """Informacoes leves para a tela de Configuracoes."""
    con = conectar(); cur = con.cursor()
    cur.execute("SELECT COUNT(*) FROM atividades")
    total = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM atividades WHERE tipo_entrada='VOZ'")
    voz = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM historico")
    historico = cur.fetchone()[0]
    con.close()
    return {
        "caminho": DB_PATH,
        "total": total,
        "voz": voz,
        "historico": historico,
    }


def limpar_banco(apagar_audios=True):
    """
    Zera os dados do Cockpit mantendo o arquivo SQLite/schema pronto para uso.
    E o equivalente operacional a apagar cockpit.db e abrir o app novamente,
    mas evita problemas de arquivo em uso no Windows.
    """
    con = conectar(); cur = con.cursor()
    cur.execute("SELECT audio_arquivo FROM atividades WHERE audio_arquivo IS NOT NULL AND audio_arquivo <> ''")
    audios = [r[0] for r in cur.fetchall()]
    cur.execute("SELECT COUNT(*) FROM atividades")
    total = cur.fetchone()[0]

    cur.execute("DELETE FROM historico")
    cur.execute("DELETE FROM atividades")
    cur.execute("DELETE FROM responsaveis")
    cur.execute("DELETE FROM configuracoes")
    try:
        cur.execute("DELETE FROM sqlite_sequence WHERE name IN ('atividades','historico','responsaveis')")
    except Exception:
        pass
    con.commit(); con.close()

    apagados = 0
    if apagar_audios:
        # Remove os audios referenciados e tambem WAVs orfaos na pasta padrao.
        for caminho in audios:
            if _remover_audio_seguro(caminho):
                apagados += 1
        pasta_audio = os.path.abspath(os.path.join(PASTA_DADOS, "..", "audios"))
        try:
            if os.path.isdir(pasta_audio):
                for nome in os.listdir(pasta_audio):
                    if nome.lower().endswith(".wav"):
                        caminho = os.path.join(pasta_audio, nome)
                        if os.path.isfile(caminho) and caminho not in audios:
                            if _remover_audio_seguro(caminho):
                                apagados += 1
        except Exception as e:
            print(f"[db] falha ao limpar pasta de audios: {e}")

    return {"ok": True, "apagadas": total, "audios_apagados": apagados, "caminho": DB_PATH}

# ---------------------------------------------------------------------------
# Responsaveis
# ---------------------------------------------------------------------------
def _registrar_responsavel(cur, nome):
    nome = (nome or "").strip()
    if nome:
        cur.execute("INSERT OR IGNORE INTO responsaveis (nome) VALUES (?)", (nome,))


def listar_responsaveis():
    con = conectar(); cur = con.cursor()
    cur.execute("SELECT nome FROM responsaveis ORDER BY nome")
    nomes = [r["nome"] for r in cur.fetchall()]
    con.close()
    return nomes


# ---------------------------------------------------------------------------
# Configuracoes (nao guarda a chave da IA — so metadados)
# ---------------------------------------------------------------------------
def set_config(chave, valor):
    con = conectar(); cur = con.cursor()
    cur.execute("INSERT OR REPLACE INTO configuracoes (chave, valor) VALUES (?,?)",
                (chave, str(valor)))
    con.commit(); con.close()


def get_config(chave, padrao=None):
    con = conectar(); cur = con.cursor()
    cur.execute("SELECT valor FROM configuracoes WHERE chave=?", (chave,))
    r = cur.fetchone()
    con.close()
    return r["valor"] if r else padrao


# ---------------------------------------------------------------------------
# Consultas para o cockpit
# ---------------------------------------------------------------------------
def _linha(r):
    d = dict(r)
    return d


def caixa_entrada():
    con = conectar(); cur = con.cursor()
    cur.execute("SELECT * FROM atividades WHERE status='entrada' ORDER BY id ASC")
    linhas = [_linha(r) for r in cur.fetchall()]
    con.close()
    return linhas


def atencao():
    """Ativas criticas, atrasadas ou para hoje — o que pede atencao."""
    hoje = _hoje_iso()
    con = conectar(); cur = con.cursor()
    cur.execute(
        """
        SELECT * FROM atividades
        WHERE status='ativa'
          AND (prioridade='critica' OR (prazo IS NOT NULL AND prazo <= ?))
        ORDER BY
          CASE prioridade WHEN 'critica' THEN 0 WHEN 'alta' THEN 1 ELSE 2 END,
          prazo IS NULL, prazo ASC
        """,
        (hoje,),
    )
    linhas = [_linha(r) for r in cur.fetchall()]
    con.close()
    return linhas


def ativas():
    con = conectar(); cur = con.cursor()
    cur.execute("SELECT * FROM atividades WHERE status='ativa' ORDER BY prazo IS NULL, prazo ASC, id ASC")
    linhas = [_linha(r) for r in cur.fetchall()]
    con.close()
    return linhas


def decisoes():
    con = conectar(); cur = con.cursor()
    cur.execute("SELECT * FROM atividades WHERE status='aguardando_decisao' OR (precisa_decisao=1 AND status NOT IN ('concluida','cancelada')) ORDER BY prazo IS NULL, prazo ASC")
    linhas = [_linha(r) for r in cur.fetchall()]
    con.close()
    return linhas


def aguardando():
    con = conectar(); cur = con.cursor()
    cur.execute("SELECT * FROM atividades WHERE status='aguardando_terceiro' ORDER BY followup_em IS NULL, followup_em ASC")
    linhas = []
    hoje = _hoje_iso()
    for r in cur.fetchall():
        d = _linha(r)
        d["dias"] = _dias_desde(d.get("aguardando_desde"))
        d["cobrar"] = bool(d.get("followup_em") and d["followup_em"] <= hoje)
        linhas.append(d)
    con.close()
    return linhas


def contadores():
    hoje = _hoje_iso()
    con = conectar(); cur = con.cursor()

    cur.execute("SELECT COUNT(*) FROM atividades WHERE status='ativa' AND prioridade='critica'")
    criticos = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM atividades WHERE status='ativa' AND prazo = ?", (hoje,))
    hoje_c = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM atividades WHERE status='ativa' AND prazo IS NOT NULL AND prazo < ?", (hoje,))
    atrasados = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM atividades WHERE status='aguardando_decisao' OR (precisa_decisao=1 AND status NOT IN ('concluida','cancelada'))")
    decisoes_c = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM atividades WHERE status='aguardando_terceiro'")
    aguardando_c = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM atividades WHERE status='aguardando_terceiro' AND followup_em IS NOT NULL AND followup_em <= ?", (hoje,))
    cobrar_c = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM atividades WHERE status='entrada'")
    entrada_c = cur.fetchone()[0]

    con.close()
    return {
        "criticos": criticos, "hoje": hoje_c, "atrasados": atrasados,
        "decisoes": decisoes_c, "aguardando": aguardando_c,
        "cobrar": cobrar_c, "entrada": entrada_c,
    }


def detalhe(ativ_id):
    con = conectar(); cur = con.cursor()
    cur.execute("SELECT * FROM atividades WHERE id=?", (ativ_id,))
    r = cur.fetchone()
    if not r:
        con.close()
        return None
    ativ = _linha(r)
    cur.execute("SELECT evento, detalhe, em FROM historico WHERE atividade_id=? ORDER BY id DESC", (ativ_id,))
    hist = [dict(x) for x in cur.fetchall()]
    con.close()
    return {"atividade": ativ, "historico": hist}


def para_export(status_filtro="Todos", ini=None, fim=None):
    con = conectar(); cur = con.cursor()
    sql = "SELECT * FROM atividades WHERE 1=1"
    params = []
    if status_filtro and status_filtro != "Todos":
        sql += " AND status=?"
        params.append(status_filtro)
    if ini:
        sql += " AND date(criado_em) >= date(?)"
        params.append(ini)
    if fim:
        sql += " AND date(criado_em) <= date(?)"
        params.append(fim)
    sql += " ORDER BY prazo IS NULL, prazo ASC, id ASC"
    cur.execute(sql, params)
    linhas = [_linha(r) for r in cur.fetchall()]
    con.close()
    return linhas


def por_ids(ids):
    if not ids:
        return []
    con = conectar(); cur = con.cursor()
    marca = ",".join("?" * len(ids))
    cur.execute(f"SELECT * FROM atividades WHERE id IN ({marca})", ids)
    linhas = [_linha(r) for r in cur.fetchall()]
    con.close()
    return linhas


def listar_ultimas(limite=50):
    con = conectar(); cur = con.cursor()
    cur.execute("SELECT codigo, status, texto_original, criado_em FROM atividades ORDER BY id DESC LIMIT ?", (limite,))
    linhas = cur.fetchall()
    con.close()
    return linhas


if __name__ == "__main__":
    inicializar()
    print("Banco em:", DB_PATH)
    print("Contadores:", contadores())
    print("Ultimas atividades:")
    for r in listar_ultimas(20):
        print(f"  {r['codigo']} | {r['status']:20} | {r['texto_original']}")
