@echo off
setlocal EnableExtensions
set "ROOT=%~dp0"
cd /d "%ROOT%"
if not exist "%ROOT%diagnostico_voz.py" (
  echo ERRO: diagnostico_voz.py nao encontrado.
  echo Extraia TODO o ZIP antes de executar este arquivo.
  pause
  exit /b 3
)
if exist "%ROOT%.venv\Scripts\python.exe" (
  "%ROOT%.venv\Scripts\python.exe" "%ROOT%diagnostico_voz.py"
) else (
  echo AVISO: .venv nao existe. Execute instalar_voz.bat primeiro.
  echo.
  python "%ROOT%diagnostico_voz.py"
)
echo.
pause
