# -*- coding: utf-8 -*-
"""
export_excel.py — Geracao de Excel a partir do banco (SAIDA).

100% local, sem IA. Usa openpyxl.
Padrao de celula: Calibri Light 8pt (conforme padrao do usuario).
A mesma base gera visoes diferentes (operacional x executivo).
"""

import os
from datetime import datetime

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

import db


AZUL = "0083CA"
AZUL_ESCURO = "003C64"
CINZA_BORDA = "CCCCCC"
HEADER_FILL = "E8F3FA"


def _pasta_export():
    pasta = os.path.join(db.PASTA_DADOS, "..", "exports")
    pasta = os.path.abspath(pasta)
    os.makedirs(pasta, exist_ok=True)
    return pasta


def _fonte(bold=False, cor="333333"):
    return Font(name="Calibri Light", size=8, bold=bold, color=cor)


def _borda():
    fina = Side(style="thin", color=CINZA_BORDA)
    return Border(left=fina, right=fina, top=fina, bottom=fina)


def _escrever_cabecalho(ws, colunas):
    borda = _borda()
    for c, titulo in enumerate(colunas, start=1):
        cel = ws.cell(row=1, column=c, value=titulo)
        cel.font = _fonte(bold=True, cor=AZUL_ESCURO)
        cel.fill = PatternFill("solid", fgColor=HEADER_FILL)
        cel.alignment = Alignment(vertical="center", horizontal="left", wrap_text=True)
        cel.border = borda


def _escrever_linha(ws, r, valores):
    borda = _borda()
    for c, v in enumerate(valores, start=1):
        cel = ws.cell(row=r, column=c, value=v)
        cel.font = _fonte()
        cel.alignment = Alignment(vertical="center", horizontal="left", wrap_text=True)
        cel.border = borda


def _ajustar_larguras(ws, larguras):
    for i, w in enumerate(larguras, start=1):
        ws.column_dimensions[ws.cell(row=1, column=i).column_letter].width = w


def _prazo_br(iso):
    if not iso:
        return ""
    try:
        return datetime.strptime(iso[:10], "%Y-%m-%d").strftime("%d/%m/%Y")
    except Exception:
        return iso


def plano_operacional(linhas, caminho):
    wb = Workbook()
    ws = wb.active
    ws.title = "Plano de Acao DP"
    colunas = ["ID", "Atividade", "Owner", "Prioridade", "Status", "Prazo", "Progresso"]
    _escrever_cabecalho(ws, colunas)
    r = 2
    for a in linhas:
        _escrever_linha(ws, r, [
            a.get("codigo", ""),
            a.get("titulo") or a.get("texto_original", ""),
            a.get("owner") or "Anderson",
            (a.get("prioridade") or "").capitalize(),
            a.get("status", ""),
            _prazo_br(a.get("prazo")),
            f"{a.get('progresso', 0)}%",
        ])
        r += 1
    _ajustar_larguras(ws, [16, 48, 14, 12, 20, 12, 10])
    ws.freeze_panes = "A2"
    wb.save(caminho)
    return caminho


def plano_executivo(linhas, caminho):
    wb = Workbook()
    ws = wb.active
    ws.title = "Plano Executivo"
    colunas = ["Tema", "Risco", "Impacto", "Decisao necessaria", "Prazo"]
    _escrever_cabecalho(ws, colunas)
    r = 2
    for a in linhas:
        _escrever_linha(ws, r, [
            a.get("titulo") or a.get("texto_original", ""),
            a.get("risco") or "",
            a.get("impacto") or "",
            a.get("decisao_necessaria") or "",
            _prazo_br(a.get("prazo")),
        ])
        r += 1
    _ajustar_larguras(ws, [40, 16, 20, 36, 12])
    ws.freeze_panes = "A2"
    wb.save(caminho)
    return caminho


def base_completa(linhas, caminho):
    wb = Workbook()
    ws = wb.active
    ws.title = "Base completa"
    colunas = ["ID", "Titulo", "Status", "Prioridade", "Prazo", "Aguardando",
               "Categoria", "Programa", "Risco", "Impacto", "Notes", "Criado em"]
    _escrever_cabecalho(ws, colunas)
    r = 2
    for a in linhas:
        _escrever_linha(ws, r, [
            a.get("codigo", ""),
            a.get("titulo") or a.get("texto_original", ""),
            a.get("status", ""),
            (a.get("prioridade") or "").capitalize(),
            _prazo_br(a.get("prazo")),
            a.get("aguardando_quem") or "",
            a.get("categoria") or "",
            a.get("programa") or "",
            a.get("risco") or "",
            a.get("impacto") or "",
            a.get("notes") or "",
            a.get("criado_em") or "",
        ])
        r += 1
    _ajustar_larguras(ws, [16, 40, 20, 12, 12, 14, 16, 18, 14, 18, 30, 18])
    ws.freeze_panes = "A2"
    wb.save(caminho)
    return caminho


def gerar(modelo="operacional", status_filtro="Todos", ini=None, fim=None):
    """
    modelo: 'operacional' | 'executivo' | 'base'
    Retorna o caminho do arquivo gerado.
    """
    linhas = db.para_export(status_filtro=status_filtro, ini=ini, fim=fim)
    carimbo = datetime.now().strftime("%Y%m%d_%H%M")
    pasta = _pasta_export()

    if modelo == "executivo":
        caminho = os.path.join(pasta, f"Plano_Executivo_{carimbo}.xlsx")
        return plano_executivo(linhas, caminho)
    elif modelo == "base":
        caminho = os.path.join(pasta, f"Base_Completa_{carimbo}.xlsx")
        return base_completa(linhas, caminho)
    else:
        caminho = os.path.join(pasta, f"Plano_Acao_DP_{carimbo}.xlsx")
        return plano_operacional(linhas, caminho)


if __name__ == "__main__":
    db.inicializar()
    print("Gerado:", gerar("operacional"))
