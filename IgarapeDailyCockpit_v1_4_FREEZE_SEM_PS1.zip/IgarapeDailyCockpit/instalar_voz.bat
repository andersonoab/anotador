@echo off
setlocal EnableExtensions
set "ROOT=%~dp0"
cd /d "%ROOT%"

echo =====================================================
echo Igarape Daily Cockpit - preparar ambiente de voz
echo =====================================================
echo.

REM Quando o BAT e aberto diretamente dentro de um ZIP, o Windows costuma
REM extrair somente o BAT para uma pasta Temp. Nessa situacao os demais
REM arquivos do projeto nao existem ao lado dele e a instalacao nao pode seguir.
if not exist "%ROOT%requirements.txt" goto :nao_extraido
if not exist "%ROOT%main.py" goto :nao_extraido
if not exist "%ROOT%audio.py" goto :nao_extraido

where python >nul 2>nul
if errorlevel 1 (
  echo ERRO: Python nao foi encontrado no PATH.
  echo Instale/ajuste o Python 3.10+ e execute novamente.
  pause
  exit /b 1
)

echo [1/5] Python encontrado:
python -c "import sys; print(sys.executable); print(sys.version)"
if errorlevel 1 goto :erro

echo.
echo [2/5] Criando ambiente isolado .venv...
if not exist "%ROOT%.venv\Scripts\python.exe" (
  python -m venv "%ROOT%.venv"
  if errorlevel 1 goto :erro
) else (
  echo Ambiente .venv ja existe - mantendo.
)

set "PY=%ROOT%.venv\Scripts\python.exe"

echo.
echo [3/5] Atualizando pip e instalando dependencias no MESMO Python do app...
"%PY%" -m pip install --upgrade pip
if errorlevel 1 goto :erro
"%PY%" -m pip install -r "%ROOT%requirements.txt"
if errorlevel 1 goto :erro

echo.
echo [4/5] Validando faster-whisper...
"%PY%" -c "import sys, faster_whisper; print('Python do app:',sys.executable); print('faster-whisper OK:', faster_whisper.__file__)"
if errorlevel 1 goto :erro

echo.
echo [5/5] Baixando/preparando o modelo Whisper base...
set "HF_HUB_DISABLE_SYMLINKS_WARNING=1"
"%PY%" -c "from faster_whisper import WhisperModel; print('Carregando modelo base...'); WhisperModel('base', device='cpu', compute_type='int8'); print('Modelo Whisper base pronto para uso local.')"
if errorlevel 1 (
  echo.
  echo ATENCAO: faster-whisper foi instalado, mas o modelo nao pode ser carregado.
  echo Normalmente isso ocorre por proxy, SSL ou bloqueio de download do Hugging Face.
  echo O Cockpit foi preparado, mas a transcricao so funcionara quando o modelo estiver local.
  echo Execute este arquivo novamente quando a rede permitir o download.
  echo.
  pause
  exit /b 2
)

echo.
echo =====================================================
echo INSTALACAO CONCLUIDA
echo Python do Cockpit: "%PY%"
echo A partir de agora use iniciar.bat para abrir o Cockpit.
echo =====================================================
echo.
pause
exit /b 0

:nao_extraido
echo ERRO: os arquivos do projeto nao estao ao lado deste instalador.
echo.
echo Isso normalmente acontece quando instalar_voz.bat e executado DIRETO
ECHO de dentro do arquivo ZIP. O Windows cria uma pasta temporaria e leva
ECHO somente o BAT, por isso requirements.txt nao e encontrado.
echo.
echo CORRECAO:
echo   1. Feche esta janela.
echo   2. No ZIP, escolha "Extrair tudo".
echo   3. Preferencialmente extraia para C:\_RPA\IgarapeDailyCockpit
echo   4. Entre na pasta extraida IgarapeDailyCockpit.
echo   5. Execute instalar_voz.bat novamente.
echo.
echo Pasta atual:
echo   %ROOT%
echo.
pause
exit /b 3

:erro
echo.
echo ERRO: a preparacao da voz nao foi concluida.
echo Copie as ultimas linhas exibidas acima se precisar diagnosticar.
echo.
pause
exit /b 1
