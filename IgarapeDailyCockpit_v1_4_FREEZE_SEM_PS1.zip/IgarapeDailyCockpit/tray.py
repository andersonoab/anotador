# -*- coding: utf-8 -*-
"""
tray.py — Icone na bandeja do Windows. Mantem o app sempre ativo e da acesso
a captura e ao cockpit mesmo se o atalho global for bloqueado pela GPO.

Depende de: pystray + Pillow.
"""

import threading

import pystray
from PIL import Image, ImageDraw


def _criar_icone():
    img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.ellipse((6, 6, 58, 58), fill=(0, 131, 202, 255))     # #0083CA
    d.ellipse((24, 24, 40, 40), fill=(255, 255, 255, 255))
    return img


def iniciar_tray(on_captura, on_cockpit, on_sair):
    def _run():
        menu = pystray.Menu(
            pystray.MenuItem("Captura rapida", lambda i, it: on_captura(), default=True),
            pystray.MenuItem("Abrir cockpit", lambda i, it: on_cockpit()),
            pystray.MenuItem("Sair", lambda i, it: (i.stop(), on_sair())),
        )
        icon = pystray.Icon("igarape_daily_cockpit", _criar_icone(),
                            "Igarape Daily Cockpit", menu)
        icon.run()

    th = threading.Thread(target=_run, daemon=True, name="tray-loop")
    th.start()
    return th
