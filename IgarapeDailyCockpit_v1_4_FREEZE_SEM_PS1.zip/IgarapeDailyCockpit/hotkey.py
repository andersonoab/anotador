# -*- coding: utf-8 -*-
"""
hotkey.py — Atalho global do Windows via RegisterHotKey (ctypes).

Escolha proposital: nao usa hook de teclado (que parece keylogger e costuma
ser bloqueado por GPO/antivirus). RegisterHotKey registra UM atalho junto ao
sistema. Zero dependencia externa. So Windows.
"""

import ctypes
import ctypes.wintypes as wt
import threading

MOD_ALT = 0x0001
MOD_CONTROL = 0x0002
MOD_SHIFT = 0x0004
MOD_WIN = 0x0008
WM_HOTKEY = 0x0312
VK_SPACE = 0x20


def iniciar_hotkey(callback, modificadores=MOD_CONTROL | MOD_ALT,
                   tecla=VK_SPACE, hotkey_id=1):
    def _loop():
        user32 = ctypes.windll.user32
        if not user32.RegisterHotKey(None, hotkey_id, modificadores, tecla):
            print("[hotkey] FALHA ao registrar atalho global (em uso ou GPO).")
            print("[hotkey] Use o icone da bandeja para abrir a captura.")
            return
        print("[hotkey] Atalho global registrado: Ctrl+Alt+Espaco")
        msg = wt.MSG()
        try:
            while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) != 0:
                if msg.message == WM_HOTKEY:
                    try:
                        callback()
                    except Exception as e:
                        print("[hotkey] erro no callback:", e)
                user32.TranslateMessage(ctypes.byref(msg))
                user32.DispatchMessageW(ctypes.byref(msg))
        finally:
            user32.UnregisterHotKey(None, hotkey_id)

    th = threading.Thread(target=_loop, daemon=True, name="hotkey-loop")
    th.start()
    return th
