# -*- coding: utf-8 -*-
"""
audio.py — gravacao e transcricao local de notas de voz.

Fluxo principal:
1) grava WAV local;
2) transcreve com faster-whisper no MESMO Python que executa o app;
3) somente se o Whisper estiver indisponivel/falhar, tenta Windows Speech.

O Windows Speech e apenas contingencia. O app nao depende de existir um pacote
pt-BR no Windows quando o faster-whisper esta corretamente instalado.
"""

import importlib.util
import os
import sys
import subprocess
import threading
from datetime import datetime

try:
    import sounddevice as _sd
    import soundfile as _sf
    DISPONIVEL = True
except Exception:
    _sd = None
    _sf = None
    DISPONIVEL = False

import db

TAXA = 16000
CANAIS = 1


def _base_aplicacao():
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def _modelo_whisper_padrao():
    local = os.path.join(_base_aplicacao(), "models", "faster-whisper-base")
    if os.path.isdir(local):
        return local
    return "base"


MODELO_WHISPER = os.getenv("IGARAPE_WHISPER_MODEL") or _modelo_whisper_padrao()

_modelo_whisper = None
_modelo_lock = threading.Lock()


def _pasta_audio():
    pasta = os.path.join(db.PASTA_DADOS, "..", "audios")
    pasta = os.path.abspath(pasta)
    os.makedirs(pasta, exist_ok=True)
    return pasta


def _whisper_instalado():
    return importlib.util.find_spec("faster_whisper") is not None


def _windows_tem_pt():
    """Checagem leve do reconhecedor pt-*; nunca levanta excecao."""
    if os.name != "nt":
        return False
    script = r"""
$ErrorActionPreference = 'SilentlyContinue'
Add-Type -AssemblyName System.Speech
$infos = [System.Speech.Recognition.SpeechRecognitionEngine]::InstalledRecognizers()
if ($infos | Where-Object { $_.Culture.Name -like 'pt-*' } | Select-Object -First 1) { '1' } else { '0' }
"""
    try:
        proc = subprocess.run(
            ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
            capture_output=True,
            text=True,
            timeout=15,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        return (proc.stdout or "").strip().endswith("1")
    except Exception:
        return False


def status_transcricao():
    whisper = _whisper_instalado()
    windows_pt = _windows_tem_pt()
    return {
        "disponivel": bool(whisper or windows_pt),
        "whisper_instalado": whisper,
        "windows_disponivel": os.name == "nt",
        "windows_portugues": windows_pt,
        "modelo": MODELO_WHISPER,
        "modo": "local",
        "preferido": "faster-whisper",
    }


def _transcrever_whisper(caminho):
    global _modelo_whisper
    from faster_whisper import WhisperModel

    with _modelo_lock:
        if _modelo_whisper is None:
            _modelo_whisper = WhisperModel(
                MODELO_WHISPER,
                device="cpu",
                compute_type="int8",
            )
        modelo = _modelo_whisper

    segmentos, _info = modelo.transcribe(
        caminho,
        language="pt",
        beam_size=3,
        vad_filter=True,
        condition_on_previous_text=True,
    )
    partes = []
    for seg in segmentos:
        t = (seg.text or "").strip()
        if t:
            partes.append(t)
    texto = " ".join(partes).strip()
    if not texto:
        raise RuntimeError("Nenhuma fala foi reconhecida pelo Whisper.")
    return texto


def _limpar_erro_windows(texto):
    texto = (texto or "").strip()
    if "Nenhum reconhecedor de fala em portugues" in texto:
        return "Nenhum reconhecedor de fala em portugues esta instalado no Windows."
    # PowerShell pode devolver stack/CategoryInfo. Para o usuario, a primeira
    # linha costuma ser suficiente e evita poluir a interface/log.
    linhas = [x.strip() for x in texto.splitlines() if x.strip()]
    return linhas[0] if linhas else "Falha no reconhecimento do Windows."


def _transcrever_windows(caminho):
    if os.name != "nt":
        raise RuntimeError("Reconhecimento de fala do Windows indisponivel neste sistema.")

    caminho_ps = os.path.abspath(caminho).replace("'", "''")
    script = rf"""
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Speech
$infos = [System.Speech.Recognition.SpeechRecognitionEngine]::InstalledRecognizers()
$info = $infos | Where-Object {{ $_.Culture.Name -eq 'pt-BR' }} | Select-Object -First 1
if ($null -eq $info) {{
  $info = $infos | Where-Object {{ $_.Culture.Name -like 'pt-*' }} | Select-Object -First 1
}}
if ($null -eq $info) {{ throw 'Nenhum reconhecedor de fala em portugues esta instalado no Windows.' }}
$rec = New-Object System.Speech.Recognition.SpeechRecognitionEngine($info.Culture)
$rec.LoadGrammar((New-Object System.Speech.Recognition.DictationGrammar))
$rec.SetInputToWaveFile('{caminho_ps}')
$partes = New-Object System.Collections.Generic.List[string]
while ($true) {{
  $r = $rec.Recognize()
  if ($null -eq $r) {{ break }}
  if (-not [string]::IsNullOrWhiteSpace($r.Text)) {{ [void]$partes.Add($r.Text.Trim()) }}
}}
$rec.Dispose()
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
[Console]::Write(($partes -join ' '))
"""
    proc = subprocess.run(
        ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=180,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    if proc.returncode != 0:
        raise RuntimeError(_limpar_erro_windows(proc.stderr or proc.stdout))
    texto = (proc.stdout or "").strip()
    if not texto:
        raise RuntimeError("O Windows nao reconheceu fala no audio.")
    return texto


def _erro_whisper_amigavel(exc):
    msg = str(exc or "").strip()
    baixa = msg.lower()
    if any(x in baixa for x in ("huggingface", "connection", "proxy", "ssl", "certificate", "timeout", "offline")):
        return (
            "Whisper instalado, mas o modelo local nao pode ser carregado/baixado. "
            "Execute instalar_voz.bat novamente com acesso ao download do modelo. "
            f"Detalhe: {msg}"
        )
    return f"Whisper falhou: {msg or type(exc).__name__}"


def transcrever(caminho):
    """Transcreve um WAV local e retorna um dicionario padronizado."""
    if not caminho or not os.path.isfile(caminho):
        return {"ok": False, "erro": "Arquivo de audio nao encontrado.", "motor": None}

    erros = []
    whisper = _whisper_instalado()

    if whisper:
        try:
            return {
                "ok": True,
                "texto": _transcrever_whisper(caminho),
                "motor": f"faster-whisper/{MODELO_WHISPER}",
            }
        except Exception as e:
            erros.append(_erro_whisper_amigavel(e))
    else:
        erros.append(
            "faster-whisper nao esta instalado no Python que executou o Cockpit. "
            "Feche o app e execute instalar_voz.bat na pasta do projeto."
        )

    # Windows Speech e apenas contingencia e so vale a pena chamar quando ha
    # reconhecedor em portugues. Assim evitamos a stack do PowerShell que voce viu.
    if _windows_tem_pt():
        try:
            return {"ok": True, "texto": _transcrever_windows(caminho), "motor": "Windows Speech/pt"}
        except Exception as e:
            erros.append(f"Windows Speech falhou: {e}")

    return {"ok": False, "erro": " | ".join(erros), "motor": None}


class Gravador:
    """Grava enquanto ativo; para e salva quando solicitado."""

    def __init__(self):
        self._buffers = []
        self._stream = None
        self._gravando = False
        self._lock = threading.Lock()
        self._inicio = None

    def iniciar(self):
        if not DISPONIVEL:
            return {"ok": False, "erro": "Bibliotecas de audio nao instaladas."}
        if self._gravando:
            return {"ok": False, "erro": "Ja esta gravando."}
        self._buffers = []

        def _callback(indata, frames, time, status):
            with self._lock:
                self._buffers.append(indata.copy())

        try:
            self._stream = _sd.InputStream(
                samplerate=TAXA,
                channels=CANAIS,
                dtype="float32",
                callback=_callback,
            )
            self._stream.start()
            self._inicio = datetime.now()
            self._gravando = True
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "erro": str(e)}

    def cancelar(self):
        if not self._gravando:
            return {"ok": True}
        try:
            self._stream.stop()
            self._stream.close()
        except Exception:
            pass
        self._gravando = False
        with self._lock:
            self._buffers = []
        self._inicio = None
        return {"ok": True}

    def parar(self):
        if not self._gravando:
            return {"ok": False, "erro": "Nao esta gravando."}
        try:
            self._stream.stop()
            self._stream.close()
        except Exception:
            pass
        self._gravando = False

        try:
            import numpy as np
        except Exception:
            return {"ok": False, "erro": "numpy nao disponivel."}

        with self._lock:
            if not self._buffers:
                return {"ok": False, "erro": "Nada gravado."}
            dados = np.concatenate(self._buffers, axis=0)

        nome = f"audio_{datetime.now().strftime('%Y%m%d_%H%M%S')}.wav"
        caminho = os.path.join(_pasta_audio(), nome)
        try:
            _sf.write(caminho, dados, TAXA, subtype="PCM_16")
        except Exception as e:
            return {"ok": False, "erro": str(e)}

        duracao = round(float(len(dados)) / TAXA, 1)
        return {"ok": True, "arquivo": caminho, "nome": nome, "duracao": duracao}


if __name__ == "__main__":
    import sys
    print("Python:", sys.executable)
    print("Audio disponivel:", DISPONIVEL)
    print("Transcricao:", status_transcricao())
