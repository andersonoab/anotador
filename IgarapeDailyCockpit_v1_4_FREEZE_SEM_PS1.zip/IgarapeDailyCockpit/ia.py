# -*- coding: utf-8 -*-
"""
ia.py — Camada de IA OPCIONAL do Igarape Daily Cockpit.

Filosofia (nao negociavel):
  - O nucleo do app funciona 100% SEM esta camada.
  - A IA so entra para GERAR PLANO DE ACAO, quando voce clicar.
  - Nada e enviado automaticamente. Nunca.
  - A chave NUNCA fica no banco/JSON: vai para o Windows Credential Manager
    (via keyring). O banco guarda so metadados (provedor/modelo/ativa).
  - Antes de enviar, o usuario REVISA e EDITA o texto (feito na interface).
    Aqui so recebemos o texto ja revisado.

Rede: usa urllib (stdlib). O proxy corporativo e respeitado automaticamente
se as variaveis de ambiente HTTP_PROXY/HTTPS_PROXY estiverem definidas.
Se o proxy bloquear api.anthropic.com, a funcao retorna erro amigavel — e o
nucleo do app segue funcionando normalmente.
"""

import json
import urllib.request
import urllib.error

try:
    import keyring
    KEYRING_OK = True
except Exception:
    KEYRING_OK = False

import db


SERVICO_KEYRING = "IgarapeDailyCockpit"
USUARIO_KEYRING = "ANTHROPIC_API_KEY"

# Modelo padrao (Haiku — rapido e barato). Pode ser trocado nas configuracoes.
# Se este identificador mudar no futuro, ajuste aqui ou em configuracoes.
MODELO_PADRAO = "claude-haiku-4-5-20251001"

ENDPOINT = "https://api.anthropic.com/v1/messages"
VERSAO_API = "2023-06-01"


# ---------------------------------------------------------------------------
# Chave (keyring)
# ---------------------------------------------------------------------------
def salvar_chave(chave):
    if not KEYRING_OK:
        return {"ok": False, "erro": "keyring nao instalado (pip install keyring)"}
    chave = (chave or "").strip()
    if not chave:
        return {"ok": False, "erro": "chave vazia"}
    try:
        keyring.set_password(SERVICO_KEYRING, USUARIO_KEYRING, chave)
        db.set_config("ia_provedor", "anthropic")
        db.set_config("ia_ativa", "1")
        return {"ok": True}
    except Exception as e:
        return {"ok": False, "erro": str(e)}


def _ler_chave():
    if not KEYRING_OK:
        return None
    try:
        return keyring.get_password(SERVICO_KEYRING, USUARIO_KEYRING)
    except Exception:
        return None


def tem_chave():
    return bool(_ler_chave())


def apagar_chave():
    if not KEYRING_OK:
        return {"ok": False, "erro": "keyring nao instalado"}
    try:
        keyring.delete_password(SERVICO_KEYRING, USUARIO_KEYRING)
    except Exception:
        pass
    db.set_config("ia_ativa", "0")
    return {"ok": True}


def modelo_atual():
    return db.get_config("ia_modelo", MODELO_PADRAO)


def status():
    return {
        "keyring_ok": KEYRING_OK,
        "tem_chave": tem_chave(),
        "provedor": db.get_config("ia_provedor", "anthropic"),
        "modelo": modelo_atual(),
        "ativa": db.get_config("ia_ativa", "0") == "1",
    }


# ---------------------------------------------------------------------------
# Chamada de baixo nivel
# ---------------------------------------------------------------------------
def _chamar(system_prompt, user_prompt, max_tokens=1500):
    chave = _ler_chave()
    if not chave:
        return {"ok": False, "erro": "Nenhuma chave de API configurada."}

    corpo = json.dumps({
        "model": modelo_atual(),
        "max_tokens": max_tokens,
        "system": system_prompt,
        "messages": [{"role": "user", "content": user_prompt}],
    }).encode("utf-8")

    req = urllib.request.Request(ENDPOINT, data=corpo, method="POST")
    req.add_header("x-api-key", chave)
    req.add_header("anthropic-version", VERSAO_API)
    req.add_header("content-type", "application/json")

    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            dados = json.loads(resp.read().decode("utf-8"))
        partes = [b.get("text", "") for b in dados.get("content", []) if b.get("type") == "text"]
        return {"ok": True, "texto": "\n".join(partes).strip()}
    except urllib.error.HTTPError as e:
        try:
            detalhe = e.read().decode("utf-8")
        except Exception:
            detalhe = str(e)
        return {"ok": False, "erro": f"HTTP {e.code}: {detalhe[:300]}"}
    except urllib.error.URLError as e:
        return {"ok": False,
                "erro": f"Sem conexao com a API (proxy da rede pode estar bloqueando). Detalhe: {e.reason}"}
    except Exception as e:
        return {"ok": False, "erro": str(e)}


def testar_conexao():
    """Ping simples para saber se o proxy libera a API."""
    r = _chamar(
        system_prompt="Responda apenas OK.",
        user_prompt="teste de conexao",
        max_tokens=10,
    )
    if r.get("ok"):
        return {"ok": True, "mensagem": "Conexao com a IA funcionou."}
    return {"ok": False, "mensagem": r.get("erro", "falha desconhecida")}


# ---------------------------------------------------------------------------
# Plano de acao (o uso principal da IA)
# ---------------------------------------------------------------------------
def gerar_plano(texto_revisado, publico="equipe"):
    """
    Recebe o texto JA REVISADO/EDITADO pelo usuario (sem dados sensiveis)
    e devolve um plano de acao estruturado.

    publico: 'equipe' (operacional) ou 'diretoria' (executivo).
    """
    if not (texto_revisado or "").strip():
        return {"ok": False, "erro": "texto vazio"}

    if publico == "diretoria":
        system = (
            "Voce e um assistente de planejamento de DP/RH. Monte um PLANO "
            "EXECUTIVO conciso para a diretoria a partir das atividades dadas. "
            "Para cada tema relevante indique: Tema, Risco, Impacto, Decisao "
            "necessaria e Prazo. Seja direto, agrupe por relevancia. "
            "Nao invente dados que nao estejam no texto."
        )
    else:
        system = (
            "Voce e um assistente de planejamento de DP/RH. Monte um PLANO DE "
            "ACAO OPERACIONAL a partir das atividades dadas. Agrupe por programa/"
            "categoria, sugira sequencia logica, aponte dependencias e riscos, e "
            "defina a proxima acao de cada item. Nao invente dados alem do texto."
        )

    return _chamar(system_prompt=system, user_prompt=texto_revisado, max_tokens=2000)


if __name__ == "__main__":
    print("Status IA:", status())
