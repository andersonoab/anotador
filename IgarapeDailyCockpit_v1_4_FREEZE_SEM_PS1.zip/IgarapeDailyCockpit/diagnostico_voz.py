# -*- coding: utf-8 -*-
"""Diagnostico simples do ambiente de voz do Igarape Daily Cockpit."""
import importlib.util
import os
import sys

print("=== Igarape Daily Cockpit / Diagnostico de Voz ===")
print("Python:", sys.executable)
print("Versao:", sys.version.replace("\n", " "))
print("SO:", os.name)

for nome in ("sounddevice", "soundfile", "numpy", "faster_whisper"):
    spec = importlib.util.find_spec(nome)
    print(f"{nome}: {'OK' if spec else 'NAO INSTALADO'}", (spec.origin if spec else ""))

if importlib.util.find_spec("faster_whisper"):
    try:
        from faster_whisper import WhisperModel
        print("Carregando modelo base...")
        WhisperModel("base", device="cpu", compute_type="int8")
        print("Whisper/modelo base: OK")
    except Exception as e:
        print("Whisper/modelo base: ERRO")
        print(type(e).__name__ + ":", e)
else:
    print("Whisper/modelo base: NAO TESTADO - faster_whisper ausente")
